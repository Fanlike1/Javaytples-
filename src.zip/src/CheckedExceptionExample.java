import java.io.FileInputStream;

public class CheckedExceptionExample {

	public static void level2() throws FileNotFoundE
		
		FileInputStream in;
		try {
		in =new FileInputStream("input.txt");
		}catch(FileNotFoundException e) {
		
	}

}
	public static void main(String[] args) {
		try {
			level
		}
	}
