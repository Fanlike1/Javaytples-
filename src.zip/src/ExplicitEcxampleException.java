
public class ExplicitEcxampleException {

	static boolean throwExceptionFlag= true;
		
		
		public static void level2() {
			System.out.println("Entering level1");
			
			if(throwExceptionFlag) {
				throw new ArrayIndexOutofBoundException ("oopsy");
			System.out.println("Entering level1");

		
		
		
		public static void level1() {
			
			
			System.out.println("Entering level1");
			level2();
			System.out.println("Entering level1");

		}

		public static void main(String[] args) {
			int[] myArray =("Entering level1");
			level2();
//			int x =5;
//			System.out.println(x/0);
			System.out.println(myArray[17]);

		}

	}
		// TODO Auto-generated method stub

	}

}
