
public class ExceptionExampleCatch {
	
	static int exceptionType = 0;

	public static void main(String[] args) {
		try {
		int x=5
		System.out.println("before devision is Zero");
		if(exceptionType == 0) {
			
		}
		
		System.out.println("after devision is Zero");
		if(exceptionType == 1) {
			throw new  ArrayIndexOutBoundsException("Generated exception";)
		}

		
		} catch (ArithmeticException caughtException) {
			System.out.println("ohh, there was an arithemetic Exception");
		}
	}

}
