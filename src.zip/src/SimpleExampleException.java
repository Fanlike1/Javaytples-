
public class SimpleExampleException {
	
	
public static void level2() {
		
		System.out.println("Entering level1");
		level2();
		System.out.println("Entering level1");

	
	
	
	public static void level1() {
		
		
		System.out.println("Entering level1");
		level2();
		System.out.println("Entering level1");

	}

	public static void main(String[] args) {
		int[] myArray =("Entering level1");
		level2();
//		int x =5;
//		System.out.println(x/0);
		System.out.println(myArray[17]);

	}

}


//exceptions happen when there is an abnomar condition or error

// and exception 








