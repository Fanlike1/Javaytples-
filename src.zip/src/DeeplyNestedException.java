
public class DeeplyNestedException {
	 static int level=0;
		
		
		
	public static void increaseLevel1() {
		if(level >= 50) {
			int a=5;
			System.out.println(5/0);
			}
		level +- 1;
		
		int x=level;
		System.out.println("Before:"+x);
		increaseLevel1();
		System.out.println("After:"+x);
		
		System.out.println(x);

	}

}
